/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class CountryConfig
	{
		id : number;
		name : string;
		city_num : number;
		icon : string;
		reward : array;
		pre_id : number;
		next_country : number;
	}
}