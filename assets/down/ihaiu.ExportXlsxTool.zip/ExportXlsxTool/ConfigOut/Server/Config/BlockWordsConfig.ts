/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class BlockWordsConfig
	{
		id : number;
		text : string;
	}
}