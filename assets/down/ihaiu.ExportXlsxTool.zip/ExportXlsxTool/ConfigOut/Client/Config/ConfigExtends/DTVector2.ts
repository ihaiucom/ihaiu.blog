/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class DTVector2 extends DTVector2Struct
	{
	}
}