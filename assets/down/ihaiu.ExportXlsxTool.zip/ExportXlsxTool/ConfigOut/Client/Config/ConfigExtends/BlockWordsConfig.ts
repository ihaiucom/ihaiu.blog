/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class BlockWordsConfig extends BlockWordsConfigStruct
	{
	}
}