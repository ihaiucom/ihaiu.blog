/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class CountryConfig extends CountryConfigStruct
	{
	}
}