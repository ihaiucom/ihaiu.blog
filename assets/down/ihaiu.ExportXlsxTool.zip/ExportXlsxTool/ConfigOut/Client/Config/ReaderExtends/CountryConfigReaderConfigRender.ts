/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class CountryConfigReader extends CountryConfigReaderStruct
	{
	}
}