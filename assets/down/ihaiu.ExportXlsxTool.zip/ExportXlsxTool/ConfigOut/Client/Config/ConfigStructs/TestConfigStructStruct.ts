/////////////////////////////////////
// ExportXlsx生成
// http://blog.ihaiu.com
/////////////////////////////////////

namespace configs
{
	export class TestConfigStruct extends BaseConfig
	{

		id : number;
		name : string;
		age : number;
		intArray : number[];
		coin : DTItemNum;
		items : DTItemNum[];
		position : DTVector2;
		story : DTStoryNum;




	}


}