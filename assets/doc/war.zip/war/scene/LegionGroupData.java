package game.fightserver.war.scene;

import java.util.HashMap;
import java.util.Map;

public class LegionGroupData
{
	/** 联盟ID */
	public int id;
	/** 联盟势力列表 */
	public Map<Integer, LegionData> dict = new HashMap<Integer, LegionData>(); 

    public int count = 0;
	
	public LegionGroupData(int groupId)
	{
		id = groupId;
	}
	
	/** 联盟添加势力 */
	public void AddLegion(LegionData legionData)
	{
		dict.put(legionData.legionId, legionData);
		legionData.group = this;
        count++;
	}
	
	/** 目标势力是否和自己是同盟 */
	public boolean IsOnceGroup(int legionId)
	{
		return dict.containsKey(legionId);
	}
}
