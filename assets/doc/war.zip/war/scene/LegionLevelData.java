package game.fightserver.war.scene;

public class LegionLevelData
{
	public float	intBattleForce = 25;
	public float	intProduceSpeed = 1;
	public float	intMoveSpeed = 1;
	public float 	initHP = 0;
}
