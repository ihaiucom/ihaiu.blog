package game.fightserver.war.scene;

import java.util.HashMap;
import java.util.Map;

import game.fightserver.war.War;
import game.fightserver.war.enums.LegionType;
import game.fightserver.war.prop.PropId;
import game.fightserver.war.prop.PropUtils;
import game.fightserver.war.room.WarEnterData;
import game.fightserver.war.room.WarEnterLegionData;
import game.fightserver.war.room.WarRoom;
import game.gameserver.config.reader.ConstVarsConfigReader;
import game.gameserver.config.reader.StageConfigBean;
import game.gameserver.config.reader.StageConfigReader;
import game.gameserver.config.reader.StagePosConfigBean;
import game.gameserver.config.reader.StagePosConfigReader;
import game.gameserver.module.role.var.Parameter;

public class SceneData 
{
	/** 战斗房间 */
	public WarRoom				room;
	
	/** 进入战斗数据 */
	private WarEnterData 		enterData;

	/** 关卡配置 */
	private StageConfigBean 	stageConfig;
	
	/** 关卡建筑配置 */
	private StagePosConfigBean 	stagePosConfig;
	
	

	/** 势力数据 */
	public Map<Integer, LegionData> 		legionDict 			= new HashMap<Integer, LegionData>();
	/** 势力联盟数据 */
	public Map<Integer, LegionGroupData> 	legionGroupDict 	= new HashMap<Integer, LegionGroupData>();
	
	
	public LegionData getLegionData(int legionId)
	{
		if(legionDict.containsKey(legionId))
		{
			return legionDict.get(legionId);
		}
		
		return null;
	}
	
	
	
	
	public SceneData (WarRoom room)
	{
		this.room = room;
	}
	
	public SceneData Generate(WarEnterData enterData)
	{

		this.stageConfig = StageConfigReader.getInstance().getConfig(enterData.stageId);
		this.stagePosConfig = StagePosConfigReader.getInstance().getConfig(enterData.stageId);
		
		room.timeMax 	= stageConfig.getLimitTime();
		room.timeLimit 	= room.timeMax > 0;
		room.time		= 0;
		
		
		GenerationLegions();
		GenerationSoliders();
		GenerationBuilds();
		
		return this;
	}
	

	/** 生成数据--势力 */
	private void GenerationLegions()
	{
		for(WarEnterLegionData enterLegionData: enterData.legionList)
		{
			// group
			LegionGroupData groupData;
			if(legionGroupDict.containsKey(enterLegionData.groupId))
			{
				groupData = legionGroupDict.get(enterLegionData.groupId);
			}
			else
			{
				groupData = new LegionGroupData(enterLegionData.groupId);
				legionGroupDict.put(groupData.id, groupData);
			}
			
			// create legion data
			LegionData legionData = new LegionData();
			legionData.roleId 		= enterLegionData.roleId;
			legionData.legionId 	= enterLegionData.legionId;
			legionData.name			= enterLegionData.name;
			groupData.AddLegion(legionData);
			legionDict.put(legionData.legionId, legionData);
			
			// legiontType
			if(legionData.legionId == War.NEUTRALL_LEGION_ID)
			{
				legionData.type = LegionType.Neutral;
			}
			else
			{
				if(enterLegionData.isRobot)
				{
					legionData.type = LegionType.Computer;
				}
				else
				{
					legionData.type = LegionType.Player;
				}
			}
			
			// legion init props
			
			int heroCount = enterLegionData.heroList.size();
			float initMaxMage = (float) Math.floor( room.timeMax / (heroCount + 1) );
			 if (initMaxMage < 15)
             {
				 initMaxMage = (float) Math.floor( (room.timeMax - 15) / heroCount);
             }
			 
			 float defaultMaxMage =  ConstVarsConfigReader.getInstance().getConfig(Parameter.War_DV_Team_MaxMage_Default).getFloatValue();

             if (initMaxMage > defaultMaxMage)
             {
            	 initMaxMage = defaultMaxMage;
             }
			
			
			legionData.legionInitProps[PropId.InitMaxMage] 		= initMaxMage;
			legionData.legionInitProps[PropId.InitMageSpeed] 	= 1;
			legionData.legionInitProps[PropId.MagAdd] 			= 0;
			
		}
	}
	
	
	/** 生成数据--士兵 */
	private void GenerationSoliders()
	{
		for(WarEnterLegionData enterLegionData: enterData.legionList)
		{
			LegionData legionData = getLegionData(enterLegionData.legionId);
			legionData.soliderInitProps = PropUtils.PropsToInit( PropUtils.PropAdd(legionData.soliderInitProps, enterLegionData.solider.props) );
			legionData.soliderInitProps[PropId.InitBattleForce] = legionData.levelData.intBattleForce;
			legionData.soliderInitProps[PropId.InitMoveSpeed]	= legionData.levelData.intMoveSpeed;
		}
	}
	
	/** 生成数据--兵营 */
	private void GenerationBuilds()
	{
		
		for(LegionData legionData : legionDict.values())
		{
			legionData.buildInitProps[PropId.InitProduceSpeed] 	= legionData.levelData.intProduceSpeed;
			legionData.buildInitProps[PropId.InitBattleForce] 	= legionData.levelData.intBattleForce;
			

			 float defaultMin =  ConstVarsConfigReader.getInstance().getConfig(Parameter.War_DV_Casern_MaxHp_DefaultMin).getFloatValue();
			 float ratio =  ConstVarsConfigReader.getInstance().getConfig(Parameter.War_DV_Casern_MaxHp_Ratio).getFloatValue();
			legionData.buildInitProps[PropId.InitMaxHp]			= defaultMin * ratio;
			
		}
		
		

	}
	
	
}
