package game.fightserver.war.scene;

import game.fightserver.war.enums.LegionType;
import game.fightserver.war.prop.PropId;

/** 势力数据 */
public class LegionData 
{
	/** 角色ID */
	public int roleId;
	
	/** 势力ID */
	public int legionId;

	/** 名称 */
	public String name;

	/** 势力类型 (玩家，机器人，野外) */
	public LegionType type;
	
	/** 所在组 */
	public LegionGroupData group;
	

	/** 势力等级 */
	public LegionLevelData levelData = new LegionLevelData();
	
	
	
	//===============================
	// 初始属性
	//--------------------------------
	public float[] 	legionInitProps 	= new float[PropId.MAX];
	public float[] 	buildInitProps 		= new float[PropId.MAX];
	public float[] 	soliderInitProps 	= new float[PropId.MAX];
	public float[]	heroInitProps		= new float[PropId.MAX];
	
	
	
}
