package game.fightserver.war.prop;

import java.util.HashMap;
import java.util.Map;

import game.fightserver.war.signal.IOnUnitPropClear;

/** 属性节点 */
public class PropNode implements IOnUnitPropClear
{
	/** 附加属性数据 */
	public AttachPropData attachPropData;
	/** 节点ID */
	public int getUid()
	{
		return attachPropData.uid;
	}
	/** 应用属性的单位 */
	public Map<Integer, IPropUnit>  unitDict = new HashMap<Integer, IPropUnit>();

	
	
	
	/** 单位--应用附加属性 */
	public void UnitApp(IPropUnit unit)
	{
		UnitApp(unit, false);
	}
	/** 单位--应用附加属性 */
	public void UnitApp(IPropUnit unit, boolean calculate)
	{
		if(unitDict.containsKey(unit.getId()))
		{
			UnitRevoke(unit);
		}

		unit.AppProps(attachPropData, calculate);
		unitDict.put(unit.getId(), unit);
		unit.getClearPropSignal().add(this);
	}
	
	
	
	
	
	/** 单位--移除附加属性 */
	public void UnitRevoke(IPropUnit unit)
	{
		UnitRevoke(unit, false);
	}

	/** 单位--移除附加属性 */
	public void UnitRevoke(IPropUnit unit, boolean calculate)
	{
		unit.RevokeProps(attachPropData, calculate);
		unit.getClearPropSignal().remove(this);
		unitDict.remove(unit.getId());
	}
	
	
	
	
	/** 销毁属性节点 */
	public void Destroy()
	{
		for(IPropUnit unit : unitDict.values())
		{

			unit.RevokeProps(attachPropData, true);
			unit.getClearPropSignal().remove(this);
		}

		unitDict.clear();

	}

	/** 单位清除属性事件，一般士兵死亡时、建筑换势力时调用 */
	public void OnUnitCleanProp(IPropUnit unit)
	{
		UnitRevoke(unit, false);
	}



	/** 构造方法 */
	public PropNode()
	{
	}

	public PropNode(AttachPropData attachPropData)
	{
		this.attachPropData = attachPropData;
	}
	

	@Override
	public String toString ()
	{
		return String.format ("[PropNdoe: uid=%d] attachPropData=%s", getUid(), attachPropData);
	}
}
