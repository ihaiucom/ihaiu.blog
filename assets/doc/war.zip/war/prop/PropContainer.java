package game.fightserver.war.prop;

import java.util.HashMap;
import java.util.Map;

import game.fightserver.war.signal.OnAddPropNodeSignal;

/** 属性容器 */
public class PropContainer
{
	/** 添加属性节点 */
	public OnAddPropNodeSignal addPropNodeSignal = new OnAddPropNodeSignal();
	

	/** 属性节点列表 */
	public Map<Integer, PropNode> nodeDict = new HashMap<Integer, PropNode>();


	/** 添加属性节点--使用附加数据 */
	public void Add(AttachPropData attachPropData)
	{
		PropNode node = new PropNode(attachPropData);
		Add(node);
	}
	
	/** 添加属性节点--PropNdoe */
	public void Add(PropNode propNode)
	{
		if(nodeDict.containsKey(propNode.getUid()))
		{
			Remove(propNode.getUid());
		}

		nodeDict.put(propNode.getUid(), propNode);
		addPropNodeSignal.dispatch(propNode);
	}

	/** 移除属性节点--id */
	public void Remove(int id)
	{
		if(nodeDict.containsKey(id))
		{
			Remove(nodeDict.get(id));
		}
	}
	
	/** 移除属性节点-- AttachPropData */
	public void Remove(AttachPropData attachPropData)
	{
		Remove(attachPropData.uid);
	}
	
	/** 移除属性节点--PropNdoe  */
	public void Remove(PropNode propNode)
	{
		propNode.Destroy();
		nodeDict.remove(propNode.getUid());
	}

	
	/** 清理属性节点 */
	public void Clear()
	{
		for(PropNode propNode : nodeDict.values())
		{
			propNode.Destroy();
		}

		nodeDict.clear();
	}
	
	
	/** 单位--应用所有节点 */
	public void UnitApp(IPropUnit unit)
	{
		UnitApp(unit, false);
	}

	/** 单位--应用所有节点 */
	public void UnitApp(IPropUnit unit, boolean calculate)
	{
		int i = 0;
		int count = nodeDict.size();
		boolean isCalculate = false;
		for(PropNode propNode : nodeDict.values())
		{
			i ++;
			isCalculate = calculate && i == count;
			propNode.UnitApp(unit, isCalculate);
		}
	}


}
