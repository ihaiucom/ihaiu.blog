package game.fightserver.war.prop;

/** 属性组 */
public class PropIdGroup
{
	/** 初始值 */
	public int init;
	/** 附加相对初始% */
	public int initPer;
	/** 附加具体值 */
	public int add;
	/** 附加相对当前% */
	public int per;
	/** 最终值 */
	public int result;

	
	/** 转换初始值 */
	public int cInit;
	/** 转换附加相对初始% */
	public int cInitPer;
	/** 转换附加具体值 */
	public int cAdd;
	/** 转换附加相对当前% */
	public int cPer;

	/** 转换最终值 */
	public int cResult;
	/** 转换比例 */
	public float cRate = 0;

	public PropIdGroup(int init, int initPer, int add, int per, int result)
	{
		this.init 		= init;
		this.initPer 	= initPer;
		this.add 		= add;
		this.per 		= per;
		this.result 	= result;
	}
}
