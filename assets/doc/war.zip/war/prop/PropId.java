package game.fightserver.war.prop;

import java.util.ArrayList;
import java.util.List;

public class PropId
{
		/** 属性最多数量，用于创建属性列表 */
        public static int MAX = 113;

		/** 兵力【血量】 */
        public static int HpAdd = 1;
        public static int HpPer = 2;
        public static int Hp = 3;

		/** 兵力上限【血量上限】 */
		public static int MaxHpAdd = 4;
		public static int MaxHpPer = 5;
		public static int MaxHp = 6;
		
		/** 人口【人口】 */
		public static int UnitNum = 7;

		/** 人口上限【人口上限】 */
		public static int MaxUnitNum = 8;
		
		/** 兵力转人口比例数值 */
		public static int Hp2UnitRate = 9;

		/** 攻击 */
        public static int AtkAdd = 10;
        public static int AtkPer = 11;
        public static int Atk = 12;
		
        /** 移动速度 */
		public static int MoveSpeedAdd = 13;
		public static int MoveSpeedPer = 14;
		public static int MoveSpeed = 15;
		
		/** 生产速度 */
		public static int ProduceSpeedAdd = 16;
		public static int ProduceSpeedPer = 17;
		public static int ProduceSpeed = 18;
		
		/** 怒气 */
		public static int MagAdd = 19;
		public static int MagPer = 20;
		public static int Mag = 21;

		/** 防御 */
		public static int DefAdd = 23;
		public static int DefPer = 24;
		public static int Def = 25;
		
		/** 普攻 */
		public static int AttackDamageAdd = 26;
		public static int AttackDamagePer = 27;
		public static int AttackDamage = 28;
		
		/** 普攻范围 */
		public static int AttackRadiusAdd = 29;
		public static int AttackRadiusPer = 30;
		public static int AttackRadius = 31;
		
		/** 普攻速度 */
		public static int AttackSpeedAdd = 32;
		public static int AttackSpeedPer = 33;
		public static int AttackSpeed = 34;
		
		/** 斩将值 */
		public static int KillHeroAdd = 35;
		public static int KillHeroPer = 36;
		public static int KillHero = 37;

		/** 防斩将值 */
		public static int DefKillHeroAdd = 38;
		public static int DefKillHeroPer = 39;
		public static int DefKillHero = 40;

		
		/** 斩将率 */
		public static int KillHeroRateAdd = 41;
		public static int KillHeroRatePer = 42;
		public static int KillHeroRate = 43;

		
		/** 怒气上限 */
		public static int MaxMagAdd = 44;
		public static int MaxMagPer = 45;
		public static int MaxMag = 46;

		/** 怒气恢复速度 */
		public static int MageSpeedAdd = 47;
		public static int MageSpeedPer = 48;
		public static int MageSpeed = 49;
		
		/** 战力 */
		public static int BattleForceAdd = 50;
		public static int BattleForcePer = 51;
		public static int BattleForce = 52;
		
		/** 速攻 */
		public static int SpeedAtkAdd = 53;
		public static int SpeedAtkPer = 54;
		public static int SpeedAtk = 55;



		
		/** 附加初始兵力 */
		public static int InitHpPer = 60;

		/** 附加初始兵力上限 */
		public static int InitMaxHpPer = 61;
		
		/** 附加初始攻击 */
		public static int InitAtkPer = 62;
		
		/** 附加初始移动速度 */
		public static int InitMoveSpeedPer = 63;
		
		/** 附加初始生产速度 */
		public static int InitProduceSpeedPer = 64;
		
		/** 附加初始怒气 */
		public static int InitMagPer = 65;
		
		/** 附加初始防御 */
		public static int InitDefPer = 66;
		
		/** 附加初始普攻 */
		public static int InitAttackDamagePer = 67;
		
		/** 附加初始普攻范围 */
		public static int InitAttackRadiusPer = 68;
		
		/** 附加初始普攻速度 */
		public static int InitAttackSpeedPer = 69;
		
		/** 附加初始必杀（斩将值） */
		public static int InitKillHeroPer = 70;
		
		/** 附加初始运气（防斩将值） */
		public static int InitDefKillHeroPer = 71;
		
		/** 附加初始斩将率 */
		public static int InitKillHeroRatePer = 72;
		
		/** 附加初始怒气上限 */
		public static int InitMaxMagePer = 73;
		
		/** 附加初始怒气恢复速度 */
		public static int InitMageSpeedPer = 74;
		
		/** 附加初始战力 */
		public static int InitBattleForcePer = 75;
		
		/** 附加初始速攻 */
		public static int InitSpeedAtkPer = 76;



		/** 初始兵力 */
		public static int InitHp = 80;
		/** 初始兵力上限 */
		public static int InitMaxHp = 81;
		/** 初始攻击 */
		public static int InitAtk = 82;
		/** 初始移动速度 */
		public static int InitMoveSpeed = 83;
		/** 初始生产速度 */
		public static int InitProduceSpeed = 84;
		/** 初始怒气 */
		public static int InitMag = 85;
		/** 初始防御 */
		public static int InitDef = 86;
		/** 初始普攻 */
		public static int InitAttackDamage = 87;
		/** 初始普攻范围 */
		public static int InitAttackRadius = 88;
		/** 初始普攻速度 */
		public static int InitAttackSpeed = 89;
		/** 初始必杀（斩将值） */
		public static int InitKillHero = 90;
		/** 初始运气（防斩将值） */
		public static int InitDefKillHero = 91;
		/** 初始斩将率 */
		public static int InitKillHeroRate = 92;
		/** 初始怒气上限 */
		public static int InitMaxMage = 93;
		/** 初始怒气恢复速度 */
		public static int InitMageSpeed = 94;
		/** 初始战力 */
		public static int InitBattleForce = 95;
		/** 初始攻速 */
		public static int InitSpeedAtk = 96;





			
		/** 状态--冰冻移动速度 */
		public static int StateFreezedMoveSpeed = 100;
		/** 状态--冰冻发兵 */
		public static int StateFreezedSendArm = 101;
		/** 状态--冰冻生产兵 */
        public static int StateFreezedProduce = 102;
        /** 状态--冰冻攻击 */
        public static int StateFreezedAtk = 103;
		/** 状态--沉默 */
		public static int StateSilence = 104;
		/** 状态--无敌 */
		public static int StateInvincible = 105;
		/** 状态--显示血量 */
		public static int StateShowHP = 106;
		/** 状态--灼烧 */
		public static int StateBurn = 107;

		/** 状态--移动速度--加 */
		public static int StateMoveSpeedUp = 108;
		/** 状态--攻击--加 */
		public static int StateAtkUp = 109;
		/** 状态--产兵--加 */
		public static int StateProduceSpeedUp = 110;

		
		/** 势力ID */
		public static int LegionID = 111;
		/** 战斗力 */
		public static int BattlePower = 112;

		
		/** 兵力【血量】 */
		public static PropIdGroup HpGroup = new PropIdGroup(InitHp, InitHpPer, HpAdd, HpPer, Hp);
		/** 兵力上限【血量上限】 */
		public static PropIdGroup MaxHpGroup = new PropIdGroup(InitMaxHp, InitMaxHpPer, MaxHpAdd, MaxHpPer, MaxHp);
		/** 攻击 */
		public static PropIdGroup AtkGroup = new PropIdGroup(InitAtk, InitAtkPer, AtkAdd, AtkPer, Atk);
		/** 移动速度 */
		public static PropIdGroup MoveSpeedGroup = new PropIdGroup(InitMoveSpeed, InitMoveSpeedPer, MoveSpeedAdd, MoveSpeedPer, MoveSpeed);
		/** 生产速度 */
		public static PropIdGroup ProduceSpeedGroup = new PropIdGroup(InitProduceSpeed, InitProduceSpeedPer, ProduceSpeedAdd, ProduceSpeedPer, ProduceSpeed);
		/** 怒气 */
		public static PropIdGroup MagGroup = new PropIdGroup(InitMag, InitMagPer, MagAdd, MagPer, Mag);
		/** 防御 */
		public static PropIdGroup DefGroup = new PropIdGroup(InitDef, InitDefPer, DefAdd, DefPer, Def);
		/** 普攻 */
		public static PropIdGroup AttackDamageGroup = new PropIdGroup(InitAttackDamage, InitAttackDamagePer, AttackDamageAdd, AttackDamagePer, AttackDamage);
		/** 普攻范围 */
		public static PropIdGroup AttackRadiusGroup = new PropIdGroup(InitAttackRadius, InitAttackRadiusPer, AttackRadiusAdd, AttackRadiusPer, AttackRadius);
		/** 普攻速度 */
		public static PropIdGroup AttackSpeedGroup = new PropIdGroup(InitAttackSpeed, InitAttackSpeedPer, AttackSpeedAdd, AttackSpeedPer, AttackSpeed);
		/** 必杀（斩将值） */
		public static PropIdGroup KillHeroGroup = new PropIdGroup(InitKillHero, InitKillHeroPer, KillHeroAdd, KillHeroPer, KillHero);
		/** 运气（防斩将值） */
		public static PropIdGroup DefKillHeroGroup = new PropIdGroup(InitDefKillHero, InitDefKillHeroPer, DefKillHeroAdd, DefKillHeroPer, DefKillHero);
		/** 斩将率 */
		public static PropIdGroup KillHeroRateGroup = new PropIdGroup(InitKillHeroRate, InitKillHeroRatePer, KillHeroRateAdd, KillHeroRatePer, KillHeroRate);
		/** 怒气上限 */
		public static PropIdGroup MaxMageGroup = new PropIdGroup(InitMaxMage, InitMaxMagePer, MaxMagAdd, MaxMagPer, MaxMag);
		/** 怒气恢复速度 */
		public static PropIdGroup MageSpeedGroup = new PropIdGroup(InitMageSpeed, InitMageSpeedPer, MageSpeedAdd, MageSpeedPer, MageSpeed);
		/** 战力 */
		public static PropIdGroup BattleForceGroup = new PropIdGroup(InitBattleForce, InitBattleForcePer, BattleForceAdd, BattleForcePer, BattleForce);
		/** 攻速 */
		public static PropIdGroup SpeedAtkGroup = new PropIdGroup(InitSpeedAtk, InitSpeedAtkPer, SpeedAtkAdd, SpeedAtkPer, SpeedAtk);

		private static  List<PropIdGroup> _listA;
		public static List<PropIdGroup> GetPropListA()
		{
			if(_listA == null)
			{
				_listA = new ArrayList<PropIdGroup>();
				_listA.add(BattleForceGroup);
				_listA.add(SpeedAtkGroup);
				_listA.add(MaxHpGroup);
//					_listA.add(AtkGroup);
//					_listA.add(DefGroup);
//					_listA.add(MoveSpeedGroup);
				_listA.add(ProduceSpeedGroup);
				_listA.add(AttackDamageGroup);
				_listA.add(AttackRadiusGroup);
				_listA.add(AttackSpeedGroup);
				_listA.add(KillHeroGroup);
				_listA.add(DefKillHeroGroup);
				_listA.add(KillHeroRateGroup);
				_listA.add(MaxMageGroup);
				_listA.add(MageSpeedGroup);
			}

			return _listA;
		}

		private static  List<PropIdGroup> _listB;
		public static List<PropIdGroup> GetPropListB()
		{
			if(_listB == null)
			{
				_listB = new ArrayList<PropIdGroup>();
				_listB.add(HpGroup);
				_listB.add(MagGroup);
			}
			
			return _listB;
		}

		private static  List<PropIdGroup> _listC;
		public static List<PropIdGroup> GetPropListC()
		{
			if(_listC == null)
			{
				AtkGroup.cInit 			= InitBattleForce;
				AtkGroup.cInitPer 		= InitBattleForcePer;
				AtkGroup.cAdd 			= BattleForceAdd;
				AtkGroup.cPer 			= BattleForcePer;
				AtkGroup.cResult 		= BattleForce;
				AtkGroup.cRate 			= 1;
				
				DefGroup.cInit = InitBattleForce;
				DefGroup.cInitPer = InitBattleForcePer;
				DefGroup.cAdd = BattleForceAdd;
				DefGroup.cPer = BattleForcePer;
				DefGroup.cResult = BattleForce;
				DefGroup.cRate = 1;

				
				MoveSpeedGroup.cInit = InitSpeedAtk;
				MoveSpeedGroup.cInitPer = InitSpeedAtkPer;
				MoveSpeedGroup.cAdd = SpeedAtkAdd;
				MoveSpeedGroup.cPer = SpeedAtkPer;
				MoveSpeedGroup.cResult = SpeedAtk;
				MoveSpeedGroup.cRate = 1;

				_listC = new ArrayList<PropIdGroup>();
				_listC.add(AtkGroup);
				_listC.add(DefGroup);
				_listC.add(MoveSpeedGroup);
			}
			
			return _listC;
		}

		
		private static  List<Integer> _listState;
		public static List<Integer> GetPropListState()
		{
			if(_listState == null)
			{
				_listState = new ArrayList<Integer>();
				_listState.add(StateFreezedMoveSpeed);
				_listState.add(StateFreezedSendArm);
                _listState.add(StateFreezedProduce);
                _listState.add(StateFreezedAtk);
				_listState.add(StateSilence);
				_listState.add(StateInvincible);
				_listState.add(StateShowHP);
			}
			
			return _listState;
		}
}
