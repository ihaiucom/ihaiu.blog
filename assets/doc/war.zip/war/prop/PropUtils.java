package game.fightserver.war.prop;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import game.gameserver.module.property.bean.Prop;

public class PropUtils
{
	public static String ToStr(Prop[] props)
	{
		String str = "{";
		String gap = "";
		for(int i = 0; i < props.length; i ++)
		{
			str += gap + props[i].toString();
			gap = ", ";
		}
		
		str += "}";
		return str;
	}
	
	
	public static void PropClear(float[] src)
	{
	    for( int i = 0 ; i < src.length ; ++ i )
	    {
	        src[i] = 0;
	    }
	}
	
	public static Map<Integer, Prop> ListToMap(List<Prop> list)
	{
		 Map<Integer, Prop> map = new HashMap<Integer, Prop>();
		for(Prop prop : list)
		{
			map.put(prop.id, prop);
		}
		
		return map;
	}
	
	
	public static float[] PropAdd(float[] src, List<Prop> propValues)
	{
		for(Prop prop : propValues)
		{
			src[prop.id] += prop.value;
		}
        return src;
    }
	
	public static float[] PropsToInit(float[] src)
	{
		
		float[] props = new float[PropId.MAX];
		List<PropIdGroup> list = PropId.GetPropListA();
		for(PropIdGroup group : list)
		{
			props[group.init] = src[group.add] * (1 + src[group.per] / 100F);
		}
		
		list = PropId.GetPropListC();
		for(PropIdGroup group : list)
		{
			props[group.init] = src[group.add] * (1 + src[group.per] / 100F);
		}

		list = PropId.GetPropListB();
		for(PropIdGroup group : list)
		{
			props[group.init] = src[group.add] * (1 + src[group.per] / 100F);
		}

		return props;
	}
  
}
