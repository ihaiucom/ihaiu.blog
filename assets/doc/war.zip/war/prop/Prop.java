//package game.fightserver.war.prop;
//
///** 属性 */
//public class Prop
//{
//	public Prop()
//	{
//		
//	}
//	
//	public Prop(int id, float val)
//	{
//		this.id 	= id;
//		this.value 	= val;
//	}
//	
//	
//	
//	/** 编号 */
//	public int 		id;
//	
//	/** 值 */
//	public float 	value;
//	
//	
//
//	/** 名称 */
//	public String	getName()
//	{
//		return getConfig().name;
//	}
//	
//	/** 附加类型(0回滚 1直接) */
//	public int 		getAdditive()
//	{
//		return getConfig().additive;
//	}
//	
//	/** 属性类型 */
//	public PropType getType()
//	{
//		return getConfig().type;
//	}
//	
//	
//	public PropConfig getConfig()
//	{
//		return PropConfig.GetInstance(id);
//	}
//	
//	
//	public static Prop CreateInstance(int id, float value)
//    {
//        return new Prop(id, value);
//    }
//	
//
//	
//	@Override
//	public String toString ()
//	{
//		if(getType() == PropType.Per || getType() == PropType.InitPer)
//		{
//			return String.format ("Prop[id=%d, %s:%f %%]",id, getName(), value);
//		}
//		else
//		{
//			return String.format ("Prop[id=%d, %s:%f]",id, getName(), value);
//		}
//	}
//
//
//}
