package game.fightserver.war.prop;

import java.util.List;

import game.fightserver.war.War;
import game.gameserver.module.property.bean.Prop;

public class PropUnitUtils
{
	/** 属性实体--添加附加 */
	public static void AppProps(IPropUnit src, AttachPropData attachPropData)
	{
		AppProps(src, attachPropData, false);
	}
	
	
	/** 属性实体--添加附加 */
	public static void AppProps(IPropUnit src, AttachPropData attachPropData, boolean calculate)
	{
		if(attachPropData == null) return;

		if(src.getAttachProps().containsKey(attachPropData.uid))
		{
			RevokeProps(src, attachPropData.uid);
		}
		
		attachPropData.App(src);

		
		if(calculate)
		{
			Calculate(src.getProps());
		}
	}
	
	

	
	
	
	
	/** 属性实体--移除附加 */
	public static void RevokeProps(IPropUnit src, int attachPropUid)
	{
		RevokeProps(src, attachPropUid, false);
	}
	
	/** 属性实体--移除附加 */
	public static void RevokeProps(IPropUnit src, int attachPropUid, boolean calculate)
	{
		if(src.getAttachProps().containsKey(attachPropUid))
		{
			RevokeProps(src, src.getAttachProps().get(attachPropUid), calculate);
		}
	}
	

	/** 属性实体--移除附加 */
	public static void RevokeProps(IPropUnit src, AttachPropData attachPropData)
	{
		RevokeProps(src, attachPropData);
	}
	

	/** 属性实体--移除附加 */
	public static void RevokeProps(IPropUnit src, AttachPropData attachPropData, boolean calculate)
	{
		if(attachPropData == null) return;
        if (src == null)
        {
            War.logger.warn("src=" + src);
            return;
        }

        try {
			if(src.getAttachProps().containsKey(attachPropData.uid))
			{
				attachPropData.Revoke(src);
			}
			
			if(calculate)
			{
				Calculate(src.getProps());
			}
        }
        catch(Exception e)
        {
            War.logger.error("src=" + src);
        }
	}

	
	
	/** 属性实体--清空 */
	public static void RevokeAll(IPropUnit src)
	{
		src.getClearPropSignal().dispatch(src);
		src.getAttachProps().clear();
		PropUtils.PropClear(src.getProps());
	}

	
	
	
	
	

	/** 计算属性 (int * (1 + intPer) + add) * (1 + per)  */
	public static void Calculate(float[] src)
	{
		List<PropIdGroup> list = PropId.GetPropListA();
		for(PropIdGroup group : list)
		{
			// result = (int * (1 + intPer) + add) * (1 + per)
			src[group.result] = ( src[group.init] * ( 1 +  src[group.initPer] ) 			+ src[group.add] ) 			* (1 + src[group.per]			/ 100F);
			src[group.result] = Prop.Limit(group.result, src[group.result]);
		}

		list = PropId.GetPropListC();
		for(PropIdGroup group : list)
		{
			// result = (int * (1 + intPer) + add + convertFinal * convertRate) * (1 + per)
			// result = ((int + cInit * cRate) 	* 	(1 + intPer + cInitPer * cRate) 			+ 	(add + cAdd * cRate) 	 * (1 + per + cPer * cRate)
			src[group.result] = ( (src[group.init]  + src[group.cInit] * group.cRate) * ( 1 +  src[group.initPer] + src[group.cInitPer] * group.cRate) 			+ src[group.add] + src[group.cAdd] * group.cRate) 			* (1 + (src[group.per]	+ src[group.cPer] * group.cRate)		/ 100F);
			src[group.result] = Prop.Limit(group.result, src[group.result]);

		}

		list = PropId.GetPropListB();
		for(PropIdGroup group : list)
		{
			src[group.result] = ( src[group.result] + src[group.init] * src[group.initPer]			+ src[group.add] ) 			* (1 + src[group.per]			/ 100F);
			src[group.initPer] = 0;
			src[group.add] = 0;
			src[group.per] = 0;
		}

	}
}
