package game.fightserver.war.prop;

import java.util.Map;

import game.fightserver.war.War;
import game.fightserver.war.signal.OnUnitPropClearSignal;

/** 属性实体 */
public interface IPropUnit
{
	/** 单位ID */
	int getId();

	/** 获取属性列表 */
	float[] getProps();
	
	/** 清除属性消息 */
	OnUnitPropClearSignal getClearPropSignal();

	/** 获取附加属性列表标记 */
	Map<Integer, AttachPropData> getAttachProps();
	
	

	//==============================================
	// PropUnitUtils
	//----------------------------------------------
	
	/** 属性实体--添加附加 */
	void AppProps(AttachPropData attachPropData);
	
	
	/** 属性实体--添加附加 */
	void AppProps(AttachPropData attachPropData, boolean calculate);
	
	
	/** 属性实体--移除附加 */
	void RevokeProps(int attachPropUid);
	
	/** 属性实体--移除附加 */
	void RevokeProps(int attachPropUid, boolean calculate);
	

	/** 属性实体--移除附加 */
	void RevokeProps(AttachPropData attachPropData);
	

	/** 属性实体--移除附加 */
	void RevokeProps(AttachPropData attachPropData, boolean calculate);
	
	/** 属性实体--清空 */
	void RevokeAll();

}
