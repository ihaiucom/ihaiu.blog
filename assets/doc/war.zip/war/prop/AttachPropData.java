package game.fightserver.war.prop;

import game.fightserver.war.War;
import game.gameserver.module.property.bean.Prop;

/** 附加属性数据 */
public class AttachPropData
{
	private static int UID = 100000;
	public int uid;
	public Prop[] props;

	public AttachPropData()
	{
		Construction(0, new Prop[]{});
	}

	
	public AttachPropData(Prop[] props)
	{
		Construction(0, props);
	}

	public AttachPropData(int uid, Prop[] props)
	{
		Construction(uid, props);
	}

	private void Construction(int uid, Prop[] props)
	{
		if(uid <= 0)
		{
			uid = UID++;
		}
		
		this.uid = uid;
		this.props = props;
	}



    /** 将附件属性 应用到 单位 */
	public void App(IPropUnit src)
	{
		int addCount = 0;
		
		float[] srcProps = src.getProps();
		
		Prop prop;
		for(int i = 0; i < props.length; i ++)
		{
			prop = props[i];
			
			if(Float.isNaN(prop.value))
			{
				War.logger.warn("<color=red>AttachPropData App prop.Value=NaN  prop={}</color>", prop);
			}
			
			if(prop.getType() == PropType.Result)
			{
				War.logger.warn("<color=red>AttachPropData App 附加属性不可以是‘最终类型’ prop={}</color>", prop);
			}
			
			srcProps[prop.id] += prop.value;
			
			if(prop.getAdditive() == 0)
			{
				addCount ++;
			}
			
			// 如果是状态 且值小于0.就把值设置为0
			if(prop.getType() == PropType.State && srcProps[prop.id] < 0)
			{
				srcProps[prop.id] = 0;
			}
			
		}
		

		if(addCount > 0)
		{
			src.getAttachProps().put(uid, this);
		}
	}

    /** ”将附件属性“ 从 “单位” 撤除 */
	public void Revoke(IPropUnit src)
	{
		float[] srcProps = src.getProps();
		Prop prop;
		for(int i = 0; i < props.length; i ++)
		{
			prop = props[i];
			
			if(Float.isNaN(prop.value))
			{
				War.logger.warn("<color=red>AttachPropData Revoke prop.Value=NaN  prop={}</color>", prop);
			}
			
			if(prop.getAdditive() == 0)
			{
				srcProps[prop.id] -= prop.value;
				// 如果是状态 且值小于0.就把值设置为0
				if(prop.getType() == PropType.State && srcProps[prop.id] < 0)
				{
					srcProps[prop.id] = 0;
				}
			}
		}
		
		if(src.getAttachProps().containsKey(uid))
		{
			src.getAttachProps().remove(uid);
		}
		
	}

	@Override
	public String toString ()
	{
		return String.format ("[AttachPropData uid=%d, props=%s]", uid, PropUtils.ToStr(props));
	}
}
