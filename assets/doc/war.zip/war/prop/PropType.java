package game.fightserver.war.prop;

public enum PropType
{
	/** 附加具体值 */
	Add(1),
	/** 附加百分比 */
	Per(2),
	/** 最终值 */
	Result(3),
	/** 附加初始百分比 */
	InitPer(4),
	/** 初始值 */
	Init(5),
	/** 状态 */
	State(6) ;
	
	
	
	private int value = 0;

    private PropType(int value) 
    { 
        this.value = value;
    }

    public static PropType valueOf(int value) 
    {   
        switch (value) 
        {
        case 1:
            return Add;
        case 2:
            return Per;
        case 3:
            return Result;
        case 4:
            return InitPer;
        case 5:
            return Init;
        case 6:
            return State;
        default:
            return null;
        }
    }

    public int value() 
    {
        return this.value;
    }
	
}
