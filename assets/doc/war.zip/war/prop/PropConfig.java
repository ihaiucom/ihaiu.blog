//package game.fightserver.war.prop;
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class PropConfig
//{
//	
//	/** 编号 */
//	public int 		id;
//	
//	/** 名称 */
//	public String	name;
//
//	
//	/** 附加类型(0回滚 1直接) */
//	public int 		additive;
//	
//	/** 属性类型 */
//	public PropType type;
//
//	
//	/** 数值下限 */
//	public float limitMinValue = -10000000; // 一千万
//	
//	/** 数值上限 */
//	public float limitMaxValue = 10000000; 	// 一千万
//	
//	
//	
//	public float limit(float val)
//	{
//		return Math.max(Math.min(val, limitMaxValue), limitMinValue);
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	private static Map<Integer, PropConfig> configs = new HashMap<Integer, PropConfig>();
//	public static PropConfig GetInstance(int id)
//    {
//        return configs.get(id);
//    }
//	
//	public static float Limit(int id, float val)
//	{
//		return configs.get(id).limit(val);
//	}
//	
//	
//	
//}
