package game.fightserver.war.signal;

import game.fightserver.war.prop.PropNode;

public interface IOnAddPropNode
{
	void OnAddPropNode(PropNode propNode);
}
