package game.fightserver.war.signal;

import game.fightserver.war.prop.IPropUnit;

public interface IOnUnitPropClear
{
	void OnUnitCleanProp(IPropUnit unit);
}
