package game.fightserver.war.signal;

import game.fightserver.war.prop.IPropUnit;

public class OnUnitPropClearSignal extends Signal<IOnUnitPropClear>
{
	public void dispatch(IPropUnit unit)
	{
		for(int i = _list.size() - 1; i >= 0; i --)
		{
			_list.get(i).OnUnitCleanProp(unit);
		}
	}
}
