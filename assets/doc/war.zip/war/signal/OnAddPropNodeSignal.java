package game.fightserver.war.signal;

import game.fightserver.war.prop.PropNode;

public class OnAddPropNodeSignal extends Signal<IOnAddPropNode>
{
	public void dispatch(PropNode propNode)
	{
		for(int i = _list.size() - 1; i >= 0; i --)
		{
			_list.get(i).OnAddPropNode(propNode);
		}
	}
}
