package game.fightserver.war.signal;

import java.util.ArrayList;


public class Signal<T>
{
	protected ArrayList<T> _list = new ArrayList<T>();
	
	public void add(T obj)
	{
		if(!_list.contains(obj))
		{
			_list.add(obj);
		}
	}
	
	public void remove(T obj)
	{
		
	}
	
//	public void dispatch()
//	{
//		for(int i = _list.size() - 1; i >= 0; i --)
//		{
//		}
//	}
}
