package game.fightserver.war.enums;

public enum LegionType
{
	/** 野外 */
	Neutral,

	/** 玩家 */
	Player,

	/** 机器人 */
	Computer,
}
