package game.fightserver.war.enums;

/** 战斗模式 */
public enum VSMode
{
	/** 副本模式 */
	Dungeon,

	/** 引导模式 */
	Train,
	
	/** 对战模式 */
	PVP,
	
	/** 异步打玩家 */
	PVE,
	
}
