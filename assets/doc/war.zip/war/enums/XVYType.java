package game.fightserver.war.enums;

/** 玩家对战数量 */
public enum XVYType
{
	_1v1,
	
	_2v2,
	
	_1v1v1,
	
	_1v1v1v1,
}
