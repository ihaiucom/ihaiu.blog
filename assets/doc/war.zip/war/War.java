package game.fightserver.war;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class War
{
	public static final Logger logger = LoggerFactory.getLogger(War.class);
	
	/** 中立势力ID */
	public static final int NEUTRALL_LEGION_ID = 0;

}
