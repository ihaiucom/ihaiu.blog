package game.fightserver.war.room;

import java.util.List;

import game.fightserver.common.FightRole;
import game.fightserver.war.scene.SceneData;

/** 战斗房间 */
public class WarRoom
{

	/** 公会消息ID （友谊战和踢馆战专用字段） */
	private int leagueMsgId;  
	
	/** 友谊战赌注 （友谊战专用字段） */
	private int leagueStake;  
	
	
	
	/** 进入战斗数据 */
	public WarEnterData 	enterData;
	
	/** 场景数据 */
	public SceneData  		sceneData;

	
	/** 战斗限制时间 */
	public boolean 	timeLimit 			= true;
	/** 战斗限制时间 */
	public float 	timeMax 			= 120;
	/** 战斗已过时间 */
	public float 	time 				= 0;
	

	
	
	public WarRoom(int matcherType, int roomId, int stageId, int hostTeamId, List<FightRole> players, int leagueMsgId, int leagueStake)
	{
		this.leagueMsgId = leagueMsgId;
		this.leagueStake = leagueStake;
		
		enterData = new WarEnterData().Generate(matcherType, roomId, stageId, players);
		sceneData = new SceneData(this).Generate(enterData);
	}
	
}
