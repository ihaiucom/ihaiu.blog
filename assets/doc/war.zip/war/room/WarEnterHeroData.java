package game.fightserver.war.room;

import java.util.ArrayList;
import java.util.List;

import game.gameserver.config.reader.CardConfigBean;
import game.gameserver.config.reader.CardConfigReader;
import game.gameserver.module.property.bean.Prop;
import game.protocol.protobuf.ProtocolCommon.ProtoCardInfo;

public class WarEnterHeroData
{
	// 英雄名称
	public String name;
	// 英雄ID
	public int heroId;
	// 英雄avatarId
	public int avatarId;
	// 技能A
	public int skillId;
	public int level;
	// 属性列表
	public List<Prop> props = new ArrayList<Prop>();
	
	public void SetProtoCardInfo(ProtoCardInfo card)
	{
		this.heroId 	= card.getCardId();
		this.level 		= card.getLevel();
		
		CardConfigBean cardConfig = CardConfigReader.getInstance().getConfig(heroId);
		name = cardConfig.getName();
		skillId = cardConfig.getSkillId();
		avatarId = cardConfig.getAvatarId();
		
		List<Prop> initProps = cardConfig.getInitProps();
		for(Prop initProp : initProps)
		{
			props.add(Prop.createInstance(initProp.id, cardConfig.getPropRealValue(initProp.id, level)));
		}
	}
}
