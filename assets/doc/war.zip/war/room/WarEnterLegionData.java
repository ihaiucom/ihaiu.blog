package game.fightserver.war.room;

import java.util.ArrayList;
import java.util.List;

import game.fightserver.common.FightRole;
import game.gameserver.config.reader.ExpConfigReader;
import game.protocol.protobuf.ProtocolCommon.ProtoCardInfo;

public class WarEnterLegionData
{
	// 玩家名称
	public String name;
	// 玩家ID
	public int roleId;
	// 阵营ID
    public int legionId;
    // 组ID
    public int groupId = -1;
	// 是否是机器人
	public boolean isRobot;
	// AI
	public int ai;
	


	// 建筑初始兵力如果是-1就读取这个值
	public float 	initHP;
	

	// 初始发兵百分比
	public int sendArmRate = 0;
    

	// 士兵数据
	public WarEnterSoliderData 		solider = new WarEnterSoliderData();

	// 英雄数据
	public List<WarEnterHeroData>  	heroList = new ArrayList<WarEnterHeroData>();
	
	
	public void SetFightRole(FightRole fightRole)
	{
		this.roleId		 	= fightRole.getRoleId();
		this.legionId 		= fightRole.getLegionId();
		this.groupId 		= fightRole.getGroupId();
		this.isRobot 		= fightRole.isRobot();
		this.ai 			= fightRole.getFightRole().getRobotAi();
		this.name 			= fightRole.getFightRole().getRoleInfo().getName();
		
		this.initHP = ExpConfigReader.getInstance().getConfig(fightRole.getFightRole().getRoleInfo().getLevel()).getProp().value;
		
		solider.avatarId = fightRole.getFightRole().getBattleInfo().getBattleSoldier();
		
		List<ProtoCardInfo> cards = fightRole.getFightRole().getBattleInfo().getBattleCardsList();
		for(ProtoCardInfo card : cards)
		{
			WarEnterHeroData enterHeroData = new WarEnterHeroData();
			enterHeroData.SetProtoCardInfo(card);
			heroList.add(enterHeroData);
		}
		
	}
	
	public void SetNeutral()
	{
		this.name		= "中立";
		this.roleId		= 0;
		this.legionId	= 0;
		this.groupId 	= 0;
		this.isRobot	= true;
		this.ai 		= 0;
		this.initHP 	= ExpConfigReader.getInstance().getConfig(1).getProp().value;
	}
			
}
