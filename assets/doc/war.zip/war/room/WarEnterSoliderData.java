package game.fightserver.war.room;

import java.util.ArrayList;
import java.util.List;

import game.fightserver.war.prop.PropId;
import game.gameserver.module.property.bean.Prop;

public class WarEnterSoliderData
{
	// 士兵ID
	public int id;

	// 士兵名称
	public String name;
	// 士兵等级
	public int level;
	// 士兵avatarId
	public int avatarId;
	// 属性列表
	public List<Prop> props;
	
	public WarEnterSoliderData()
	{
		props = new ArrayList<Prop>();
		props.add(Prop.createInstance(PropId.MaxHpAdd, 1));
		props.add(Prop.createInstance(PropId.KillHeroAdd, 100));
	}
}
