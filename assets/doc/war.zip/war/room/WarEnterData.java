package game.fightserver.war.room;

import java.util.ArrayList;
import java.util.List;

import game.fightserver.common.FightRole;
import game.fightserver.war.enums.VSMode;
import game.fightserver.war.enums.XVYType;
import game.zoneserver.matcher.var.MatcherType;

public class WarEnterData
{
	// 如果是PVP，房间ID
	public int 			roomId;
	// 关卡ID
	public int 			stageId;
	// 战斗模式
    public VSMode 		vsmode;

    // 玩家对战数量模式
    public XVYType 		xvy = XVYType._1v1;

	// 玩家战前数据
	public  List<WarEnterLegionData> legionList = new ArrayList<WarEnterLegionData>();
	
	
	public WarEnterData Generate(int matcherType, int roomId, int stageId, List<FightRole> players)
	{
		this.roomId 	= roomId;
		this.stageId 	= stageId;
		this.vsmode 	= VSMode.PVP;
		this.xvy		= MatcherType.toXvY(matcherType);
		
		boolean hasNeutral = false;
		for(FightRole fightRole : players)
		{
			WarEnterLegionData enterLegionData = new WarEnterLegionData();
			enterLegionData.SetFightRole(fightRole);
			legionList.add(enterLegionData);
			if(enterLegionData.legionId == 0)
			{
				hasNeutral = true;
			}
		}
		
		if(!hasNeutral)
		{

			WarEnterLegionData enterLegionData = new WarEnterLegionData();
			enterLegionData.SetNeutral();
			legionList.add(enterLegionData);
			
		}
		
		
		
		return this;
	}
}
