package game.fightserver.war.unit;

public class UnitCtl
{
	public UnitData unitData;
}
