package game.fightserver.war.unit;

import java.util.HashMap;
import java.util.Map;

import game.fightserver.war.prop.AttachPropData;
import game.fightserver.war.prop.IPropUnit;
import game.fightserver.war.prop.PropId;
import game.fightserver.war.prop.PropUnitUtils;
import game.fightserver.war.signal.OnUnitPropClearSignal;

/** 单位数据 */
public class UnitData implements IPropUnit
{
	/** 单位ID */
	public int 			id;
	
	/** 属性列表 */
	public float[] 		props = new float[PropId.MAX];

	/** 清除属性消息 */
	private OnUnitPropClearSignal			clearPropSignal = new OnUnitPropClearSignal();

	/** 获取附加属性列表标记 */
	private Map<Integer, AttachPropData> 	attachProps = new HashMap<Integer, AttachPropData>();
	
	
	
	
	
	
	
	//==============================================
	// IPropUnit
	//----------------------------------------------

	/** 单位ID */
	public int getId()
	{
		return id;
	}

	/** 获取属性列表 */
	public float[] getProps()
	{
		return props;
	}

	/** 清除属性消息 */
	public OnUnitPropClearSignal getClearPropSignal()
	{
		return clearPropSignal;
	}

	/** 获取附加属性列表标记 */
	public Map<Integer, AttachPropData> getAttachProps()
	{
		return attachProps;
	}
	

	//==============================================
	// PropUnitUtils
	//----------------------------------------------
	
	/** 属性实体--添加附加 */
	public void AppProps( AttachPropData attachPropData)
	{
		PropUnitUtils.AppProps(this, attachPropData);
	}
	
	
	/** 属性实体--添加附加 */
	public void AppProps(AttachPropData attachPropData, boolean calculate)
	{
		PropUnitUtils.AppProps(this, attachPropData, calculate);
	}
	
	
	/** 属性实体--移除附加 */
	public void RevokeProps(int attachPropUid)
	{
		PropUnitUtils.RevokeProps(this, attachPropUid);
	}
	
	/** 属性实体--移除附加 */
	public void RevokeProps(int attachPropUid, boolean calculate)
	{
		PropUnitUtils.RevokeProps(this, attachPropUid, calculate);
	}
	

	/** 属性实体--移除附加 */
	public void RevokeProps(AttachPropData attachPropData)
	{
		PropUnitUtils.RevokeProps(this, attachPropData);
	}
	

	/** 属性实体--移除附加 */
	public void RevokeProps(AttachPropData attachPropData, boolean calculate)
	{
		PropUnitUtils.RevokeProps(this, attachPropData, calculate);
	}
	
	/** 属性实体--清空 */
	public void RevokeAll()
	{
		PropUnitUtils.RevokeAll(this);
	}
	
	
	

	//==============================================
	// Init
	//----------------------------------------------
	
}
